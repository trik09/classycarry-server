const multer = require('multer');

const storage = multer.diskStorage({}); // Let multer auto-generate filename
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith('image')) {
    cb(null, true);
  } else {
    cb("Invalid image file!", false);
  }
};

const upload = multer({ storage, fileFilter });

module.exports = upload;
