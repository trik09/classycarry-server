const Category = require("../models/categoryModel"); // adjust filename if needed
const cloudinary = require('../config/cloudinary');
// ADD CATEGORY
// ADD CATEGORY WITH IMAGE
exports.createCategory = async (req, res) => {
  try {
    const { name } = req.body;

    // Upload to cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
      folder: 'categories',
    });

    const newCategory = new Category({
      name,
      image: result.secure_url, // Save image URL
    });

    await newCategory.save();
    res.status(201).json(newCategory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET ALL CATEGORIES
exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.find({}).sort({ createdAt: -1 });
    res.json(categories);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE CATEGORY (add this if using PUT)
exports.updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, slug, image } = req.body;

    const updated = await Category.findByIdAndUpdate(
      id,
      {
        name,
        slug: slug || name.toLowerCase().replace(/\s+/g, '-'),
        ...(image && { image }) // update image if sent
      },
      { new: true }
    );

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


// DELETE CATEGORY (add this if using DELETE)
exports.deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;
    await Category.findByIdAndDelete(id);
    res.json({ message: "Category deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
