const Bag = require("../models/bagModel");
const cloudinary = require('../config/cloudinary');
const fs = require('fs');


// CREATE Bag

exports.createBag = async (req, res) => {
  try {
    const { category, name, price, oldPrice, isActive, gender, minOrder } = req.body;

    // Parse colors JSON safely
    let colorsMeta = [];
    try {
      colorsMeta = req.body.colors ? JSON.parse(req.body.colors) : [];
    } catch (err) {
      console.error("Invalid colors JSON:", err);
      return res.status(400).json({ message: "Invalid colors format" });
    }

    // Files array (multer.any())
    const files = req.files || [];
    console.log("Files received:", files.map(f => f.fieldname));

    // Process color entries
    const colors = await Promise.all(
      colorsMeta.map(async (c) => {
        if (!c.name || !c.key) {
          throw new Error(`Color entry missing name/key: ${JSON.stringify(c)}`);
        }

        const fieldName = `color_${c.key}`;
        const filesForColor = files.filter(f => f.fieldname === fieldName);

        let imageUrls = [];
        if (filesForColor.length) {
          try {
            const uploads = await Promise.all(
              filesForColor.map(file =>
                cloudinary.uploader.upload(file.path, { folder: `bags/${name}_${c.key}` })
              )
            );
            imageUrls = uploads.map(u => u.secure_url);
          } finally {
            await Promise.all(filesForColor.map(file =>
              fs.promises.unlink(file.path).catch(() => {})
            ));
          }
        }

        return {
          name: c.name,
          key: c.key,
          hex: c.hex || null,
          images: imageUrls
        };
      })
    );

    // Save bag
    const newBag = new Bag({
      category,
      name,
      price,
      oldPrice,
      isActive: isActive === "true" || isActive === true,
      gender,
      minOrder: minOrder ? Number(minOrder) : 100,
      colors
    });

    await newBag.save();
    res.status(201).json(newBag);
  } catch (error) {
    console.error("createBag error:", error);
    res.status(500).json({ message: error.message });
  }
};
// GET all bags
exports.getBags = async (req, res) => {
  try {
    const bags = await Bag.find({})
      .populate("category", "name")
      .sort({ createdAt: -1 });
    res.json(bags);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET single bag by ID  <--- Add this!
exports.getBagById = async (req, res) => {
  try {
    const bag = await Bag.findById(req.params.id).populate("category", "name");
    if (!bag) return res.status(404).json({ message: "Bag not found" });
    res.json(bag);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// UPDATE bag
exports.updateBag = async (req, res) => {
  try {
    const { id } = req.params;
    const { category, name, price, oldPrice, isActive, image } = req.body;

    const updated = await Bag.findByIdAndUpdate(
      id,
      {
        category,
        name,
        price,
        oldPrice,
        isActive,
        ...(image && { image })
      },
      { new: true }
    ).populate("category", "name");

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE bag
exports.deleteBag = async (req, res) => {
  try {
    const { id } = req.params;
    await Bag.findByIdAndDelete(id);
    res.json({ message: "Bag deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
