// routes/bag.js
const express = require('express');
const router = express.Router();
const upload = require('../middlewares/multer');
const {
  createBag,
  getBags,
  getBagById,      // Import here
  updateBag,
  deleteBag
} = require('../controllers/bagController');
// const upload = require('../middlewares/multer');

router.post('/bags', upload.any(), createBag);
router.get('/bags', getBags);
router.put('/bags/:id', updateBag);
router.delete('/bags/:id', deleteBag);
router.get('/bags/:id', getBagById);


module.exports = router;
