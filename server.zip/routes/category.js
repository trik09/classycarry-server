// category.js
const express = require('express');
const router = express.Router();
const {
  createCategory,
  getCategories,
  updateCategory,
  deleteCategory
} = require('../controllers/categoryController');
const upload = require('../middlewares/multer');

// CREATE

router.post('/category', upload.single('image'), createCategory);
router.get('/category', getCategories);
// UPDATE
router.put('/category/:id', updateCategory);
// DELETE
router.delete('/category/:id', deleteCategory);

module.exports = router;
