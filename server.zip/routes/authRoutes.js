const express = require("express");
const { register, login, getAllUsers } = require("../controllers/authController");
const { auth, adminOnly } = require("../middlewares/authMiddleware");

const router = express.Router();

// Public routes
router.post("/auth/register", register);
router.post("/auth/login", login);

// Admin route
// router.get("/auth/users", auth, adminOnly, getAllUsers);
router.get("/auth/users",  getAllUsers);


module.exports = router;
