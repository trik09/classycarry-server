// models/bagModel.js
const mongoose = require('mongoose');

const colorSubSchema = new mongoose.Schema({
  name: { type: String, required: true },    // e.g. "Brown"
  key: { type: String, required: true },     // e.g. "brown" (slug, used for file field names)
  hex: { type: String },                     // optional color code for UI
  images: [{ type: String }],                // array of Cloudinary URLs
}, { _id: false });

const bagSchema = new mongoose.Schema({
  category: { type: mongoose.Schema.Types.ObjectId, ref: "Category", required: true },
  name: { type: String, required: true },
  price: { type: Number, required: true },
  oldPrice: { type: Number },
  isActive: { type: Boolean, default: true },
  gender: { type: String, enum: ['Men','Women','Unisex','Kids'], default: 'Unisex' },
  minOrder: { type: Number, default: 100 },
  colors: [colorSubSchema],
}, { timestamps: true });

module.exports = mongoose.model("Bag", bagSchema);
