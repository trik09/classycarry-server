const express = require("express");
const router = express.Router();
const {
  createBag,
  getBags,
  getBagById,
  updateBag,
  deleteBag,
} = require("../controllers/bagController");

router.post("/", createBag);
router.get("/", getBags);
router.get("/:id", getBagById);
router.put("/:id", updateBag);
router.delete("/:id", deleteBag);

module.exports = router;
