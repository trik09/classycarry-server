// models/bagModel.js
const mongoose = require('mongoose');

const colorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  images: [{ type: String }], // array of image URLs
}, { _id: false });

const bagSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  gender: { type: String, enum: ['Male', 'Female', 'Unisex'], default: 'Unisex' },
  price: { type: Number, required: true },
  description: { type: String },
  returnPolicy: { type: String },
  isActive: { type: Boolean, default: true },
  colors: [colorSchema],
}, { timestamps: true });

module.exports = mongoose.model('Bag', bagSchema);
